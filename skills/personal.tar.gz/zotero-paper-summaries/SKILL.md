---
name: zotero-paper-summaries
description: Summarize a paper from the user's local Zotero library using indexed text, a local PDF, or its abstract, with bibliographic metadata and clear source limits. Use when asked to summarize, digest, or make notes on a Zotero paper.
---

# Zotero Paper Summaries

Create a grounded Markdown summary for a **parent bibliographic item** in the local Zotero library. Retrieve metadata through Zotero's local API, then use indexed text or a locally linked PDF when available. Never change Zotero items, notes, attachments, or the database as part of this skill.

## Select the paper

- If the user gives a Zotero item key or a precise Zotero link, use its parent bibliographic item key. If the user gives a title, author, or topic, search local items with `GET http://127.0.0.1:23119/api/users/0/items?q=<URL-encoded query>` or use the installed Zotero plugin's read tools. Follow paginated results for the relevant search, and filter out attachments, notes, annotations, and other child items before matching title, authors, and year. If several parent items remain plausible, present the candidates and ask the user to choose. Do not silently use the first result.
- Do not substitute a paper found on the web for one in the library. Do not crawl the entire library for an ordinary single-paper request.
- Run `python3 scripts/fetch_paper.py ITEMKEY --mode auto` from this skill directory. `auto` prefers Zotero indexed attachment text, then extracts up to 25 pages from a locally available PDF with `pdftotext`, then falls back to the abstract. `--mode fulltext` requires one of the first two sources; `--mode abstract` uses only the abstract. Linked PDF paths with `attachments:` resolve under `~/ZotLib` by default; set `ZOTERO_ATTACHMENT_BASE` if Zotero uses a different base directory. The helper emits JSON containing metadata, source text, and coverage. If the connection fails, ask the user to start Zotero and check its local API setting. For an HTTP error, invalid item, or missing source text, report that specific problem.

## Write the summary

- Start with the paper's title, authors, year, venue, DOI when present, and `zotero://select/library/items/ITEMKEY`.
- State the evidence basis near the top: **Zotero indexed text**, **local PDF text**, or **Zotero abstract only**. For indexed text, disclose `indexed_pages` versus `total_pages` when present. For local PDF text, disclose that extraction covers at most the first 25 pages and may omit later pages. Also disclose when `pdf_output_byte_limit_hit` is true; this means extraction stopped early. If `truncated` is true, read `excerpt_strategy`: a character-limited source joins first and last excerpts with `[omitted]` (or `…` for very small limits), while a PDF stopped at its byte limit may contain only a leading portion. Treat omissions as gaps, never as evidence of consecutive passages.
- Summarize the research question, approach, main results, and limitations only where the retrieved text supports them. Distinguish the paper's claims from your own assessment. Say when a detail is absent from the available source. Do not invent sample sizes, numbers, methods, conclusions, or page citations. Zotero's indexed text does not provide reliable page positions.
- Use a short, readable Markdown structure suited to the paper. Include a final **Source limits** line even when the source appears complete; indexed text and PDF extraction may omit figures, tables, equations, or pages.
- Save a requested summary under `~/dsc/self-research/summaries/` by default, using a readable title slug plus the item key as the filename. If the user names another location, use it. If a file already exists, make a new version or ask before replacing it. For a conversational summary request without a save instruction, answer in chat and do not create a file.

The helper is deliberately bounded (`--max-chars`, default 20,000). Increase that limit only when necessary for the requested depth and identify the exact text coverage in the final summary.
