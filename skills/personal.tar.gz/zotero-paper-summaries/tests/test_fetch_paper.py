import sys
import subprocess
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from fetch_paper import ZoteroHTTPError, _extract_pdf, _local_pdf_path, fetch_paper


ITEM = {
    "key": "ABCD1234",
    "data": {
        "itemType": "journalArticle",
        "title": "A Sample Paper",
        "creators": [
            {"creatorType": "author", "firstName": "Ada", "lastName": "Lovelace"},
            {"creatorType": "editor", "firstName": "Grace", "lastName": "Hopper"},
            {"creatorType": "translator", "name": "Alan Turing"},
        ],
        "date": "2024-03-01",
        "abstractNote": "An evidence-based abstract.",
        "DOI": "10.1000/example",
        "publicationTitle": "Example Journal",
    },
}
CHILDREN = [
    {"key": "PDFX1234", "data": {
        "itemType": "attachment", "contentType": "application/pdf",
        "title": "Paper PDF", "filename": "paper.pdf", "linkMode": "imported_file",
    }}
]


class FakeClient:
    def __init__(self, fulltext=None, fulltext_error=None, children=None, texts=None):
        self.fulltext = fulltext
        self.fulltext_error = fulltext_error
        self.children = CHILDREN if children is None else children
        self.texts = texts or {}
        self.calls = []

    def get(self, path):
        self.calls.append(path)
        if path == "/api/users/0/items/ABCD1234":
            return ITEM
        if path.startswith("/api/users/0/items/ABCD1234/children?start="):
            query = path.split("?", 1)[1]
            params = dict(part.split("=", 1) for part in query.split("&"))
            start, limit = int(params["start"]), int(params["limit"])
            return self.children[start:start + limit]
        if path.endswith("/fulltext"):
            if self.fulltext_error:
                raise self.fulltext_error
            key = path.split("/")[-2]
            if key in self.texts:
                return self.texts[key]
            return self.fulltext
        raise AssertionError(f"unexpected route: {path}")


class FetchPaperTests(unittest.TestCase):
    def test_invalid_key_fails_before_request(self):
        client = FakeClient()
        with self.assertRaises(ValueError):
            fetch_paper("../../bad", client=client)
        self.assertEqual(client.calls, [])

    def test_abstract_mode_does_not_request_attachments(self):
        client = FakeClient()
        result = fetch_paper("ABCD1234", mode="abstract", client=client)
        self.assertEqual(result["source"]["kind"], "abstract")
        self.assertEqual(result["source"]["text"], "An evidence-based abstract.")
        self.assertEqual(client.calls, ["/api/users/0/items/ABCD1234"])
        self.assertEqual(result["metadata"]["authors"], ["Ada Lovelace"])

    def test_auto_falls_back_when_fulltext_is_not_indexed(self):
        client = FakeClient(fulltext_error=ZoteroHTTPError(404, "not indexed"))
        result = fetch_paper("ABCD1234", mode="auto", client=client)
        self.assertEqual(result["source"]["kind"], "abstract")
        self.assertEqual(result["source"]["fallback_reason"], "indexed full text unavailable")
        self.assertIn("/api/users/0/items/PDFX1234/fulltext", client.calls)

    def test_fulltext_reports_truncation_and_index_coverage(self):
        client = FakeClient(fulltext={
            "content": "A" * 50 + "B" * 50,
            "indexedPages": 2,
            "totalPages": 4,
        })
        result = fetch_paper("ABCD1234", mode="fulltext", max_chars=40, client=client)
        source = result["source"]
        self.assertEqual(source["kind"], "indexed_fulltext")
        self.assertEqual(source["text_chars_total"], 100)
        self.assertEqual(source["text_chars_returned"], 40)
        self.assertEqual(len(source["text"]), 40)
        self.assertIn(" [omitted] ", source["text"])
        self.assertTrue(source["truncated"])
        self.assertEqual(source["indexed_pages"], 2)
        self.assertEqual(source["total_pages"], 4)
        self.assertTrue(source["text"].startswith("A"))
        self.assertTrue(source["text"].endswith("B"))
        self.assertEqual(source["attachment_key"], "PDFX1234")
        self.assertEqual(source["attachment_content_type"], "application/pdf")
        self.assertEqual(source["attachment_title"], "Paper PDF")
        self.assertEqual(source["attachment_filename"], "paper.pdf")
        self.assertEqual(source["attachment_link_mode"], "imported_file")

    def test_short_excerpt_keeps_omission_marker_inside_limit(self):
        client = FakeClient()
        result = fetch_paper("ABCD1234", mode="abstract", max_chars=2, client=client)
        self.assertEqual(len(result["source"]["text"]), 2)
        self.assertIn("…", result["source"]["text"])

    def test_paginates_children_and_finds_pdf_after_first_page(self):
        fillers = [
            {"key": f"N{i:07d}", "data": {"itemType": "note"}}
            for i in range(100)
        ]
        client = FakeClient(children=fillers + CHILDREN, fulltext={"content": "Paper text"})
        result = fetch_paper("ABCD1234", mode="fulltext", client=client)
        self.assertEqual(result["source"]["attachment_key"], "PDFX1234")
        self.assertIn("/api/users/0/items/ABCD1234/children?start=100&limit=100", client.calls)

    def test_refuses_to_claim_fulltext_absent_when_child_search_is_incomplete(self):
        fillers = [
            {"key": f"N{i:07d}", "data": {"itemType": "note"}}
            for i in range(1_001)
        ]
        client = FakeClient(children=fillers)
        with self.assertRaisesRegex(ValueError, "Attachment search incomplete"):
            fetch_paper("ABCD1234", mode="auto", client=client)

    def test_exactly_one_thousand_children_is_a_complete_search(self):
        fillers = [
            {"key": f"N{i:07d}", "data": {"itemType": "note"}}
            for i in range(1_000)
        ]
        client = FakeClient(children=fillers)
        result = fetch_paper("ABCD1234", mode="auto", client=client)
        self.assertEqual(result["source"]["kind"], "abstract")
        self.assertIn("/api/users/0/items/ABCD1234/children?start=1000&limit=1", client.calls)

    def test_prefers_pdf_to_html_even_when_html_is_first(self):
        html = {"key": "HTML1234", "data": {
            "itemType": "attachment", "contentType": "text/html", "title": "Web snapshot",
        }}
        client = FakeClient(
            children=[html] + CHILDREN,
            texts={"HTML1234": {"content": "HTML text"}, "PDFX1234": {"content": "PDF text"}},
        )
        result = fetch_paper("ABCD1234", mode="fulltext", client=client)
        self.assertEqual(result["source"]["text"], "PDF text")
        self.assertEqual(result["source"]["attachment_content_type"], "application/pdf")
        self.assertNotIn("/api/users/0/items/HTML1234/fulltext", client.calls)

    def test_fulltext_only_does_not_silently_use_abstract(self):
        client = FakeClient(fulltext_error=ZoteroHTTPError(404, "not indexed"))
        with self.assertRaisesRegex(ValueError, "indexed full text unavailable"):
            fetch_paper("ABCD1234", mode="fulltext", client=client)

    def test_auto_uses_local_pdf_when_indexed_text_is_unavailable(self):
        with TemporaryDirectory() as directory:
            pdf = Path(directory) / "paper.pdf"
            pdf.write_bytes(b"%PDF-1.4")
            child = {"key": "PDFX1234", "data": {
                "itemType": "attachment", "contentType": "application/pdf",
                "path": str(pdf), "title": "Paper PDF",
            }}
            seen = []

            def extract(path):
                seen.append(path)
                return "Methods and results from the PDF."

            client = FakeClient(children=[child], fulltext_error=ZoteroHTTPError(404, "not indexed"))
            result = fetch_paper("ABCD1234", mode="auto", client=client, pdf_extractor=extract)
            self.assertEqual(result["source"]["kind"], "local_pdf_text")
            self.assertEqual(result["source"]["text"], "Methods and results from the PDF.")
            self.assertEqual(seen, [pdf])
            self.assertEqual(result["source"]["pdf_pages_requested"], 25)
            self.assertFalse(result["source"]["pdf_output_byte_limit_hit"])
            self.assertIn("first 25 pages", result["source"]["excerpt_strategy"])

    def test_capped_local_pdf_output_is_reported_as_incomplete(self):
        with TemporaryDirectory() as directory:
            pdf = Path(directory) / "paper.pdf"
            pdf.write_bytes(b"%PDF-1.4")
            child = {"key": "PDFX1234", "data": {
                "itemType": "attachment", "contentType": "application/pdf", "path": str(pdf),
            }}
            client = FakeClient(children=[child], fulltext_error=ZoteroHTTPError(404, "not indexed"))
            result = fetch_paper(
                "ABCD1234", mode="fulltext", client=client,
                pdf_extractor=lambda path: ("first PDF text", True),
            )
            source = result["source"]
            self.assertTrue(source["pdf_output_byte_limit_hit"])
            self.assertTrue(source["truncated"])
            self.assertIn("byte limit", source["excerpt_strategy"])
            self.assertIn("first 25 pages", source["excerpt_strategy"])

    def test_pdf_extraction_caps_output_bytes(self):
        real_popen = subprocess.Popen
        def fake_popen(_command, **kwargs):
            return real_popen(
                [sys.executable, "-c", "import sys; sys.stdout.buffer.write(b'x' * 4096)"],
                **kwargs,
            )

        with patch("fetch_paper.PDF_OUTPUT_LIMIT_BYTES", 1024), patch(
            "fetch_paper.subprocess.Popen", side_effect=fake_popen
        ):
            text, capped = _extract_pdf(Path("/unused.pdf"))
        self.assertTrue(capped)
        self.assertEqual(len(text.encode("utf-8")), 1024)

    def test_local_pdf_precedes_indexed_html(self):
        with TemporaryDirectory() as directory:
            pdf = Path(directory) / "paper.pdf"
            pdf.write_bytes(b"%PDF-1.4")
            children = [
                {"key": "HTML1234", "data": {"itemType": "attachment", "contentType": "text/html"}},
                {"key": "PDFX1234", "data": {
                    "itemType": "attachment", "contentType": "application/pdf", "path": str(pdf),
                }},
            ]
            client = FakeClient(children=children, texts={"HTML1234": {"content": "HTML text"}})
            result = fetch_paper(
                "ABCD1234", mode="fulltext", client=client,
                pdf_extractor=lambda path: "Local PDF text",
            )
            self.assertEqual(result["source"]["kind"], "local_pdf_text")
            self.assertEqual(result["source"]["text"], "Local PDF text")

    def test_relative_pdf_path_cannot_escape_attachment_base(self):
        with TemporaryDirectory() as directory:
            base = Path(directory) / "base"
            base.mkdir()
            outside = Path(directory) / "outside.pdf"
            outside.write_bytes(b"%PDF-1.4")
            with patch.dict("fetch_paper.os.environ", {"ZOTERO_ATTACHMENT_BASE": str(base)}):
                self.assertIsNone(_local_pdf_path({
                    "key": "PDFX1234", "data": {"path": "attachments:../outside.pdf"}
                }))
                (base / "link.pdf").symlink_to(outside)
                self.assertIsNone(_local_pdf_path({
                    "key": "PDFX1234", "data": {"path": "attachments:link.pdf"}
                }))

    def test_abstract_mode_never_reads_local_pdf(self):
        def extract(path):
            self.fail("abstract mode must not extract a PDF")

        result = fetch_paper("ABCD1234", mode="abstract", client=FakeClient(), pdf_extractor=extract)
        self.assertEqual(result["source"]["kind"], "abstract")


if __name__ == "__main__":
    unittest.main()
