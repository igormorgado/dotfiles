#!/usr/bin/env python3
"""Retrieve one Zotero paper and a bounded source excerpt through the local API."""

import argparse
import json
import os
import re
import selectors
import subprocess
import time
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


BASE_URL = "http://127.0.0.1:23119"
KEY_RE = re.compile(r"[A-Z0-9]{8}\Z")
CHILD_PAGE_SIZE = 100
MAX_CHILD_PAGES = 10
PDF_PAGE_LIMIT = 25
PDF_FILE_LIMIT_BYTES = 50 * 1024 * 1024
PDF_OUTPUT_LIMIT_BYTES = 4 * 1024 * 1024


class ZoteroHTTPError(Exception):
    def __init__(self, status, message):
        super().__init__(f"Zotero HTTP {status}: {message}")
        self.status = status


class LocalClient:
    def __init__(self, base_url=BASE_URL):
        self.base_url = base_url.rstrip("/")

    def get(self, path):
        request = Request(self.base_url + path, headers={"Accept": "application/json"}, method="GET")
        try:
            with urlopen(request, timeout=10) as response:
                return json.load(response)
        except HTTPError as error:
            raise ZoteroHTTPError(error.code, error.reason) from error
        except URLError as error:
            raise ConnectionError(f"Cannot reach Zotero local API: {error.reason}") from error


def _excerpt(value, max_chars):
    if len(value) <= max_chars:
        return value, False
    marker = " [omitted] " if max_chars >= len(" [omitted] ") + 2 else "…"
    available = max_chars - len(marker)
    first = (available + 1) // 2
    last = available - first
    return value[:first] + marker + (value[-last:] if last else ""), True


def _authors(creators):
    names = []
    for creator in creators:
        if creator.get("creatorType") != "author":
            continue
        name = creator.get("name") or " ".join(
            part for part in (creator.get("firstName"), creator.get("lastName")) if part
        )
        if name:
            names.append(name)
    return names


def _attachments(client, item_key):
    """Read all child pages, refusing to report a partial attachment search."""
    children = []
    for page in range(MAX_CHILD_PAGES):
        start = page * CHILD_PAGE_SIZE
        batch = client.get(
            f"/api/users/0/items/{item_key}/children?start={start}&limit={CHILD_PAGE_SIZE}"
        )
        if not isinstance(batch, list):
            raise ValueError("Zotero returned an invalid attachment list")
        children.extend(batch)
        if len(batch) < CHILD_PAGE_SIZE:
            break
    else:
        overflow = client.get(
            f"/api/users/0/items/{item_key}/children?start={MAX_CHILD_PAGES * CHILD_PAGE_SIZE}&limit=1"
        )
        if not isinstance(overflow, list):
            raise ValueError("Zotero returned an invalid attachment list")
        if overflow:
            raise ValueError("Attachment search incomplete: more than 1,000 child items exist")

    attachments = [
        child for child in children
        if child.get("data", {}).get("itemType") == "attachment"
        and child.get("data", {}).get("contentType") in {"application/pdf", "text/html"}
    ]
    return sorted(
        attachments,
        key=lambda child: child["data"]["contentType"] != "application/pdf",
    )


def _local_pdf_path(attachment):
    """Resolve only the PDF path explicitly recorded by Zotero."""
    data = attachment.get("data", {})
    raw = data.get("path") or ""
    if not isinstance(raw, str) or not raw:
        return None
    key = attachment.get("key")
    if raw.startswith("attachments:"):
        relative = Path(raw[len("attachments:"):])
        base = Path(os.environ.get("ZOTERO_ATTACHMENT_BASE", "~/ZotLib")).expanduser().resolve()
    elif raw.startswith("storage:") and isinstance(key, str) and KEY_RE.fullmatch(key):
        relative = Path(raw[len("storage:"):])
        base = (Path.home() / "Zotero" / "storage" / key).resolve()
    elif Path(raw).is_absolute():
        relative = None
        base = Path(raw).resolve()
    else:
        return None
    if relative is not None:
        if relative.is_absolute() or ".." in relative.parts:
            return None
        path = (base / relative).resolve()
        if not path.is_relative_to(base):
            return None
    else:
        path = base
    if path.suffix.lower() != ".pdf" or not path.is_file():
        return None
    try:
        if path.stat().st_size > PDF_FILE_LIMIT_BYTES:
            return None
    except OSError:
        return None
    return path


def _extract_pdf(path):
    process = None
    try:
        process = subprocess.Popen(
            ["pdftotext", "-f", "1", "-l", str(PDF_PAGE_LIMIT), "-enc", "UTF-8", str(path), "-"],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
        )
        output = bytearray()
        deadline = time.monotonic() + 20
        capped = False
        with selectors.DefaultSelector() as selector:
            selector.register(process.stdout, selectors.EVENT_READ)
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0 or not selector.select(remaining):
                    return None
                read_size = min(65536, PDF_OUTPUT_LIMIT_BYTES + 1 - len(output))
                chunk = os.read(process.stdout.fileno(), read_size)
                if not chunk:
                    break
                available = PDF_OUTPUT_LIMIT_BYTES - len(output)
                output.extend(chunk[:available])
                if len(chunk) > available:
                    capped = True
                    break
        if not capped:
            if process.wait(timeout=max(0, deadline - time.monotonic())):
                return None
        return output.decode("utf-8", errors="replace"), capped
    except (OSError, subprocess.TimeoutExpired):
        return None
    finally:
        if process is not None:
            if process.poll() is None:
                try:
                    process.kill()
                except ProcessLookupError:
                    pass
            try:
                process.wait(timeout=1)
            except subprocess.TimeoutExpired:
                pass
            if process.stdout is not None:
                process.stdout.close()


def fetch_paper(item_key, mode="auto", max_chars=20000, client=None, pdf_extractor=None):
    """Return bibliographic metadata and one source. No Zotero writes are made."""
    if not isinstance(item_key, str) or not KEY_RE.fullmatch(item_key):
        raise ValueError("item_key must be an eight-character uppercase Zotero key")
    if mode not in {"auto", "abstract", "fulltext"}:
        raise ValueError("mode must be auto, abstract, or fulltext")
    if not isinstance(max_chars, int) or isinstance(max_chars, bool) or max_chars < 2:
        raise ValueError("max_chars must be an integer of at least 2")

    client = client or LocalClient()
    item = client.get(f"/api/users/0/items/{item_key}")
    data = item.get("data", {})
    if data.get("itemType") in {"attachment", "note", "annotation"}:
        raise ValueError("Select a parent bibliographic item, not an attachment or note")
    metadata = {
        "item_key": item_key,
        "item_type": data.get("itemType"),
        "title": data.get("title"),
        "authors": _authors(data.get("creators", [])),
        "date": data.get("date"),
        "publication": data.get("publicationTitle") or data.get("bookTitle"),
        "doi": data.get("DOI"),
        "url": data.get("url"),
    }

    fallback_reason = None
    if mode != "abstract":
        attachments = _attachments(client, item_key)
        deferred_html = None
        for attachment in attachments:
            key = attachment.get("key")
            if not isinstance(key, str) or not KEY_RE.fullmatch(key):
                continue
            try:
                indexed = client.get(f"/api/users/0/items/{key}/fulltext")
            except ZoteroHTTPError as error:
                if error.status in {400, 404}:
                    continue
                raise
            content = indexed.get("content") if isinstance(indexed, dict) else None
            if not isinstance(content, str) or not content.strip():
                continue
            excerpt, truncated = _excerpt(content, max_chars)
            result = {
                "metadata": metadata,
                "source": {
                    "kind": "indexed_fulltext",
                    "attachment_key": key,
                    "attachment_title": attachment["data"].get("title"),
                    "attachment_content_type": attachment["data"].get("contentType"),
                    "attachment_link_mode": attachment["data"].get("linkMode"),
                    "attachment_filename": attachment["data"].get("filename"),
                    "attachment_url": attachment["data"].get("url"),
                    "text": excerpt,
                    "text_chars_total": len(content),
                    "text_chars_returned": len(excerpt),
                    "truncated": truncated,
                    "excerpt_strategy": "first and last characters with omission marker" if truncated else "complete indexed text",
                    "indexed_pages": indexed.get("indexedPages"),
                    "total_pages": indexed.get("totalPages"),
                },
            }
            if attachment["data"].get("contentType") == "text/html":
                deferred_html = result
            else:
                return result
        extractor = pdf_extractor or _extract_pdf
        for attachment in attachments:
            if attachment["data"].get("contentType") != "application/pdf":
                continue
            path = _local_pdf_path(attachment)
            if path is None:
                continue
            extraction = extractor(path)
            if isinstance(extraction, tuple) and len(extraction) == 2:
                content, output_byte_limit_hit = extraction
            else:
                content, output_byte_limit_hit = extraction, False
            if not isinstance(content, str) or not content.strip():
                continue
            excerpt, excerpt_truncated = _excerpt(content, max_chars)
            if output_byte_limit_hit:
                excerpt_strategy = (
                    "first and last characters of extracted text from up to the first 25 pages "
                    "with omission marker; extraction stopped at byte limit"
                    if excerpt_truncated else
                    "leading extracted text from up to the first 25 pages; extraction stopped at byte limit"
                )
            else:
                excerpt_strategy = (
                    "first and last characters of extracted text from up to the first 25 pages "
                    "with omission marker"
                    if excerpt_truncated else
                    "all extracted text from up to the first 25 pages"
                )
            return {
                "metadata": metadata,
                "source": {
                    "kind": "local_pdf_text",
                    "attachment_key": attachment["key"],
                    "attachment_title": attachment["data"].get("title"),
                    "attachment_content_type": "application/pdf",
                    "text": excerpt,
                    "text_chars_total": len(content),
                    "text_chars_returned": len(excerpt),
                    "truncated": excerpt_truncated or output_byte_limit_hit,
                    "excerpt_strategy": excerpt_strategy,
                    "pdf_pages_requested": PDF_PAGE_LIMIT,
                    "pdf_page_coverage": "up to the first 25 pages; total PDF length not determined",
                    "pdf_output_byte_limit_hit": output_byte_limit_hit,
                    "pdf_output_byte_limit_bytes": PDF_OUTPUT_LIMIT_BYTES,
                },
            }
        if deferred_html is not None:
            return deferred_html
        fallback_reason = "indexed full text unavailable"
        if mode == "fulltext":
            raise ValueError(fallback_reason)

    abstract = data.get("abstractNote") or ""
    if not abstract.strip():
        raise ValueError("No usable abstract or indexed full text is available for this item")
    excerpt, truncated = _excerpt(abstract, max_chars)
    source = {
        "kind": "abstract",
        "text": excerpt,
        "text_chars_total": len(abstract),
        "text_chars_returned": len(excerpt),
        "truncated": truncated,
        "excerpt_strategy": "first and last characters with omission marker" if truncated else "complete abstract",
    }
    if fallback_reason:
        source["fallback_reason"] = fallback_reason
    return {"metadata": metadata, "source": source}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("item_key", help="Eight-character Zotero parent item key")
    parser.add_argument("--mode", choices=("auto", "abstract", "fulltext"), default="auto")
    parser.add_argument("--max-chars", type=int, default=20000)
    args = parser.parse_args()
    try:
        result = fetch_paper(args.item_key, args.mode, args.max_chars)
    except (ValueError, ZoteroHTTPError, ConnectionError) as error:
        parser.exit(1, f"{error}\n")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
